import React from 'react'

function ActionRequir() {
    return (
        <div className=''>
            <div className='text-center bg-white h-full w-full border rounded-[10px] p-4'>
                <h4 className='font-semibold text-[#495057]'>Action Required</h4>
                <p className='pt-7 text-[#495057]'>Please insert Exp. Quantity and Exp. Delevery data</p>
            </div>
        </div>
    )
}

export default ActionRequir
